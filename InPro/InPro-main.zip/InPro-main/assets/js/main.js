(function(){
  const btn = document.querySelector('[data-burger]');
  const panel = document.querySelector('[data-mobile]');
  if(!btn || !panel) return;
  btn.addEventListener('click', () => {
    const open = panel.getAttribute('data-open') === 'true';
    panel.setAttribute('data-open', String(!open));
    panel.style.display = open ? 'none' : 'block';
    btn.setAttribute('aria-expanded', String(!open));
  });
})();
